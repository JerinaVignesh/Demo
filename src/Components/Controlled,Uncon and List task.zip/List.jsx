import React from "react";
import "../Components/List.css";
class List extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userList: [
        {
          id: 1,
          name: "Jerina",
          designation: "Developer",
        },
        {
          id: 2,
          name: "Sonali",
          designation: "Banking",
        },
        {
          id: 3,
          name: "Swathy",
          designation: "Testing",
        },
      ],
    };
  }
  render() {
    return (
      <>
        <div className="container">
          <h4 className="mt-4 mb-4">User List</h4>
          <table className="table table-striped">
            <thead>
              <tr className="table-primary">
                <th>id</th>
                <th>name</th>
                <th>designation</th>
              </tr>
            </thead>
            <tbody>
              {this.state.userList.map((user, index) => (
                <tr key={index}>
                  <td>{user.id}</td>
                  <td>{user.name}</td>
                  <td>{user.designation}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="container">
          <h4 className="mt-4 mb-4">User List</h4>
          <table className="table table-striped">
            <thead>
              <tr className="table-primary">
                <th>id</th>
                <th>name</th>
                <th>designation</th>
              </tr>
            </thead>
            <tbody>
              {this.state.userList.map((user, index) => (
                <tr key={index}>
                  <td>{user.id}</td>
                  <td>{user.name}</td>
                  <td>{user.designation}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </>
    );
  }
}

export default List;
